#!/bin/bash

# check for command line argument
if test $# -lt 1; 
  then 
  echo "Please specify the poster's filename and optionally the desired Creator/Producer string as a command-line argument"
  exit 1
fi

if test $# -ge 2;
   then
   CREATOR="InfoValue: $2"
else
   CREATOR="InfoValue: GPL Ghostscript 9.10"
fi

echo "The output will be written with the Creator/Producer string: $CREATOR"


# check ghostscript version
type gs >/dev/null 2>&1 || { echo >&2 "I require ghostscript but it's not installed.  Aborting."; exit 1; }

GSVER=`gs --version`

if [ "$GSVER" != "9.10" ];
   then
     echo "YOUR GHOSTSCRIPT VERSION IS NOT 9.10, THE CONVERSION MIGHT BE NOT WORKING!!!!"
fi

# Define useful variables
PDF=$1

# scramble the MacOS-pdf's bugs through GNU tools
pdf2ps $1
PS=$(echo $1 | sed s'/.pdf/.ps/')
ps2pdf $PS


echo "PDF-File: $PDF"
PDF_X3=X3_"$1"
echo "PDF_X3-File: $PDF_X3"
PDF_META="$1"_META
echo "Metadata: $PDF_META"

# Use ghostscript to convert the file to pdf/x-3 standard
gs -dPDFX -dBATCH -dNOPAUSE -dNOOUTERSAVE -sColorConverionStrategy=/CMYK -sProcessColorModel=DeviceCMYK -sOutputICCProfile="ISOcoated_v2_eci.icc" -sDEVICE=pdfwrite -sOutputFile=$PDF_X3 ./PDFX3_def.ps $PDF

# Use pdftk to extract the .pdfs metadata
pdftk $PDF_X3 dump_data output $PDF_META

# Modify "creator-string" of .pdf
cat $PDF_META | sed -e '/InfoKey\: Creator/{n;d}' | sed '/Creator/a '"$CREATOR"'' > ./mod.$PDF_META

# Modify "producer-string" of .pdf
cat ./mod.$PDF_META | sed -e '/InfoKey\: Producer/{n;d}' | sed '/Producer/a '"$CREATOR"'' > ./$PDF_META

# Write metadata to .pdf
pdftk $PDF_X3 update_info $PDF_META output Ready_to_Print_$PDF_X3

# clean up
rm $PDF_X3
rm $PDF_META
rm mod.$PDF_META
rm $PS
